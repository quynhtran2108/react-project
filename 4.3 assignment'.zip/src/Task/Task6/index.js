import React, { useState, useEffect } from 'react';
import photo1 from './image/photo1.jpeg';
import photo2 from './image/photo2.jpeg';
import photo3 from './image/photo3.jpeg';
import photo4 from './image/photo4.jpg';
import photo5 from './image/photo5.jpeg';
const images = [photo1, photo2, photo3, photo4, photo5];

const Task6 = () => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === 'ArrowRight') {
        setCurrentImageIndex((currentImageIndex + 1) % images.length);
      } else if (event.key === 'ArrowLeft') {
        setCurrentImageIndex((currentImageIndex + images.length - 1) % images.length);
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [currentImageIndex]);

  return (
    <div>
      <img src={images[currentImageIndex]} alt={`Image ${currentImageIndex + 1}`} />
    </div>
  );
};

  export default Task6;