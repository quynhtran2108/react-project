import logo from './logo.svg';
import './App.css';
import Task7 from './Task/Task7';

function App() {
  return (
    <div className="App">
      <Task7 />
    </div>
  );
}

export default App;
