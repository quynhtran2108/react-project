import logo from './logo.svg';
import './App.css';
import Taskbonus3 from './Task/Taskbonus3';

function App() {
  return (
    <div className="App">
      <Taskbonus3 />
    </div>
  );
}

export default App;
