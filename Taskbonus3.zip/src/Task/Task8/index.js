import React, { useState } from "react";
import { styled } from "@mui/material";
import {
  Typography,
  MenuItem,
  Select,
  Container,
  Box,
   Menu 
} from "@mui/material";
import image1 from './image/image1.jpeg';
import image2 from './image/image2.jpeg';
import image3 from './image/image3.jpeg'

const ImageContainer = styled(Box)({
  position: "relative",
  width: 500,
  height: 500,
  borderRadius: 8,
  overflow: "hidden",
});

const Image = styled("img")({
  position: "absolute",
  top: 80,
  left: 80,
  width: "100%",
  height: "100%",
  objectFit: "cover",
  transition: "opacity 0.3s ease-in-out",
});

const SelectContainer = styled(Box)({
  display: "flex",
  alignItems: "center",
  marginTop: 16,
});

const CustomSelect = styled(Select)({
  marginLeft: 16,
  color: "#fff",
  backgroundColor: "#3f51b5",
  borderRadius: 8,
  "& .MuiSelect-icon": {
    color: "#fff",
  },
});

const images = [
  {
    src: image1,
    label: "Image 1",
  },
  {
    src: image2,
    label: "Image 2",
  },
  {
    src: image3,
    label: "Image 3",
  },
];

function Task8() {
  const [selectedImage, setSelectedImage] = useState(images[0]);

  const handleImageChange = (event) => {
    const selectedLabel = event.target.value;
    const selectedImage = images.find((image) => image.label === selectedLabel);
    setSelectedImage(selectedImage);
  };

  return (
    <Container maxWidth="md">
      <ImageContainer>
        <Image src={selectedImage.src} alt={selectedImage.label} />
        <SelectContainer>
          <Typography variant="h6">Select image:</Typography>
          <CustomSelect
            value={selectedImage.label}
            onChange={handleImageChange}
            variant="outlined"
            IconComponent={Menu}
          >
            {images.map((image) => (
              <MenuItem key={image.label} value={image.label}>
                {image.label}
              </MenuItem>
            ))}
          </CustomSelect>
        </SelectContainer>
      </ImageContainer>
    </Container>
  );
}

export default Task8;

