import React from "react";
import { Button, Typography } from "@mui/material";


const Task3 = () => {
    return(
        <div>
            <Typography variant="h4">Hi, I'm Quynh Tran</Typography>
            <Button variant="text" href="mail:quynhtran.kath@gmail.com">Contact</Button>
            <Button variant="contained" href="http://www.quynhtran.co">Portfolio</Button>
            <Button variant="text" href="https://www.linkedin.com/in/quynhtran1999/">LinkedIn</Button>

        </div>
    )
}

export default Task3