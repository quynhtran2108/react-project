import React, { useState } from "react";
import { TextField, Button, Typography } from "@mui/material";
import "./index.css"

const Task4 = () => {
    const [petName, setPetName] = useState("");
    const [petType, setPetType] = useState("");
    const showMessage = () => {
        alert(`Great, you have done it`)
    }
    return (
        <div>
            <Typography variant="h5">Welcome to our pet house!</Typography>
            <div className="container"> 
                <TextField
                    label="Pet name"
                    variant="filled"
                    size="Normal"
                    onChange={setPetName}
                />
                <TextField
                    label="Type"
                    variant="filled"
                    size="Normal" 
                    onChange={setPetType}
                    />
                <Button variant="contained" onClick={showMessage}>Submit</Button>
             
            </div>
        </div>
    )
}

export default Task4