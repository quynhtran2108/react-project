import React, {useRef, useEffect} from "react";
import { Box } from "@mui/material";

const Task5 = () => {
    const [canvasSize, setCanvasSize] = React.useState([
      window.innerWidth,
      window.innerHeight,
    ]);
  
    const canvasRef = useRef(null);
  
    window.onresize = (event) => {
      setCanvasSize([window.innerWidth, window.innerHeight]);
    };
  
    useEffect(() => {
      const ctxHello = (ctx) => ctx.strokeText("Hello teacher, I'm in", 20, 50);
      const ctx = canvasRef.current.getContext("2d");
      
      ctx.font="30px Roboto"
      ctxHello(ctx);
  
      ctx.save();
      ctx.transform(2, 0, 1, 2, -1, 10);
      ctxHello(ctx);
      ctx.restore();
  
    }, []);
    return (
      <Box>
        <canvas
          width={canvasSize[0]}
          height={canvasSize[1]}
          ref={canvasRef}
          style={{ cursor: "none", zIndex: 1, position: "fixed" }}
        />
      </Box>
    );
  };
  
  export default Task5;