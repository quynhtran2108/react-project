import logo from './logo.svg';
import './App.css';
import Task5 from './Task/Task5';

function App() {
  return (
    <div className="App">
      <Task5 />
    </div>
  );
}

export default App;
