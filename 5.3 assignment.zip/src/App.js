import logo from './logo.svg';
import './App.css';
import Task8 from './Task/Task8';

function App() {
  return (
    <div className="App">
      <Task8 />
    </div>
  );
}

export default App;
