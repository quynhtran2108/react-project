import logo from './logo.svg';
import './App.css';
import Task3 from './Task/Task3';

function App() {
  return (
    <div className="App">
      <Task3 />
    </div>
  );
}

export default App;
