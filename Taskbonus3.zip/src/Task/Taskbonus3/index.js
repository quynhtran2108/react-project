import React, { useState } from "react";
import { AppBar, Toolbar, Typography, Button, Container, Fab, Card, CardContent, Menu, MenuItem } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import MoreVertIcon from '@mui/icons-material/MoreVert';

const Taskbonus3 = () => {
    const [menuAnchor, setMenuAnchor] = React.useState(null);

    const handleMenuOpen = (event) => {
        setMenuAnchor(event.currentTarget);
    };

    const handleMenuClose = () => {
        setMenuAnchor(null);
    };

    return (
        <div>
            <AppBar position="static">
                <Toolbar>
                    <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                        Task Manager
                    </Typography>
                    <Button color="inherit">Login</Button>
                    <Button color="inherit">Sign Up</Button>
                    <Button color="inherit" onClick={handleMenuOpen}>
                        <MoreVertIcon />
                    </Button>
                    <Menu anchorEl={menuAnchor} open={Boolean(menuAnchor)} onClose={handleMenuClose}>
                        <MenuItem onClick={handleMenuClose}>Settings</MenuItem>
                        <MenuItem onClick={handleMenuClose}>Logout</MenuItem>
                    </Menu>
                </Toolbar>
            </AppBar>
            <Container sx={{ padding: '2rem' }}>
                <Fab color="primary" aria-label="add" sx={{ position: 'fixed', bottom: '2rem', right: '2rem' }}>
                    <AddIcon />
                </Fab>
                <Card>
                    <CardContent>
                        <Typography variant="h5" component="div">
                            Task 1
                        </Typography>
                        <Typography sx={{ mb: 1.5 }} color="text.secondary">
                            Description for Task 1
                        </Typography>
                        <Button size="small">Details</Button>
                    </CardContent>
                </Card>
                <Card sx={{ mt: 2 }}>
                    <CardContent>
                        <Typography variant="h5" component="div">
                            Task 2
                        </Typography>
                        <Typography sx={{ mb: 1.5 }} color="text.secondary">
                            Description for Task 2
                        </Typography>
                        <Button size="small">Details</Button>
                    </CardContent>
                </Card>
            </Container>
        </div>
    );
}

export default Taskbonus3;
