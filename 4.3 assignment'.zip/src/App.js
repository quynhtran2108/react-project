import logo from './logo.svg';
import './App.css';
import Task6 from './Task/Task6';

function App() {
  return (
    <div className="App">
      <Task6 />
    </div>
  );
}

export default App;
