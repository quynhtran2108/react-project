import React, { useRef } from 'react';
import { Button, Typography } from "@mui/material";
function Task7() {
  const nodeRef = useRef(null);

  const handleClick = () => {
    if (nodeRef.current) {
      nodeRef.current.style.color = 'Blue';
      nodeRef.current.textContent = 'Thanks for submitting, have a nice day!';
    }
  };

  return (
    <div>
      <p ref={nodeRef}>Click the button to submit your application.</p>
      <button onClick={handleClick}>Submit</button>
    </div>
  );
}

export default Task7;
