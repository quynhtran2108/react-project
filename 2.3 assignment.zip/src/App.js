import logo from './logo.svg';
import './App.css';
import Task4 from './Task/Task4';

function App() {
  return (
    <div className="App">
      <Task4 />
    </div>
  );
}

export default App;
